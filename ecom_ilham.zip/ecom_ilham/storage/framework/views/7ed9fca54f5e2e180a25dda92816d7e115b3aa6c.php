<div class="logo_products">
    <div class="container">
        <div class="w3ls_logo_products_left">
            <h1>
                <a href=<?php echo e(route('home')); ?>>
                    <img src="<?php echo e(asset('images/logo.jpeg')); ?>" style="width: 120px;"></img>
                </a>
            </h1>
        </div>
        <div class="w3l_search">
            <form action="#" method="post">
                <input type="search" name="Search" placeholder="Search for a Product..." required="">
                <button type="submit" class="btn btn-default search" aria-label="Left Align">
                    <i class="fa fa-search" aria-hidden="true"> </i>
                </button>
                <div class="clearfix"></div>
            </form>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom_ilham/resources/views/logo.blade.php ENDPATH**/ ?>