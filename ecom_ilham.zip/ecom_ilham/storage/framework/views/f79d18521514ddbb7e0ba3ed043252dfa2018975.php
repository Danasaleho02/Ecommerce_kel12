<div class="agileits_header">
    <div class="container">
        <div class="agile-login">
            <ul>
                <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                    <?php if(Route::has('register')): ?>
                    <li><a href="<?php echo e(route('register')); ?>"> Daftar di sini </a></li>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </ul>
        </div>
        <div class="product_list_header">
            <form action="#" method="post" class="last">
                <input type="hidden" name="cmd" value="_cart">
                <input type="hidden" name="display" value="1">
                <button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down"
                        aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom_ilham/resources/views/aHeader.blade.php ENDPATH**/ ?>