<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<ul id="demo1">
    <li>
        <img src="images/11.jpg" alt="" />
        <div class="slide-desc">
            <h3>Persiapkan Pernikahanmu dengan Lebih Mudah</h3>
        </div>
    </li>
    <li>
        <img src="images/22.jpg" alt="" />
        <div class="slide-desc">
            <h3>Smoth your Wedding preparation in just one click</h3>
        </div>
    </li>

    <li>
        <img src="images/44.jpg" alt="" />
        <div class="slide-desc">
            <h3>Tersedia Berbagai Wedding Organizer</h3>
        </div>
    </li>
</ul>

<div class="top-brands">
    <div class="container">
        <h2>Top selling offers</h2>
        <div class="grid_3 grid_5">
            <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
                <div id="myTabContent" class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active" id="expeditions"
                        aria-labelledby="expeditions-tab">
                        <div class="agile_top_brands_grids">
                            <div class="col-md-4 top_brand_left">
                                <div class="hover14 column">
                                    <div class="agile_top_brand_left_grid">
                                        <div class="agile_top_brand_left_grid_pos">
                                            <img src="images/offer.png" alt=" " class="img-responsive" />
                                        </div>
                                        <div class="agile_top_brand_left_grid1">
                                            <figure>
                                                <div class="snipcart-item block">
                                                    <div class="snipcart-thumb">
                                                        <a href="products.html"><img title=" " alt=" "
                                                                src="images/1.png" /></a>
                                                        <p>Tata-salt</p>
                                                        <div class="stars">
                                                            <i class="fa fa-star blue-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star blue-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star blue-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star blue-star" aria-hidden="true"></i>
                                                            <i class="fa fa-star gray-star" aria-hidden="true"></i>
                                                        </div>
                                                        <h4>$20.99 <span>$35.00</span></h4>
                                                    </div>
                                                    <div class="snipcart-details top_brand_home_details">
                                                        <form action="#" method="post">
                                                            <fieldset>
                                                                <input type="hidden" name="cmd" value="_cart" />
                                                                <input type="hidden" name="add" value="1" />
                                                                <input type="hidden" name="business" value=" " />
                                                                <input type="hidden" name="item_name"
                                                                    value="Fortune Sunflower Oil" />
                                                                <input type="hidden" name="amount" value="20.99" />
                                                                <input type="hidden" name="discount_amount"
                                                                    value="1.00" />
                                                                <input type="hidden" name="currency_code" value="USD" />
                                                                <input type="hidden" name="return" value=" " />
                                                                <input type="hidden" name="cancel_return" value=" " />
                                                                <input type="submit" name="submit" value="Add to cart"
                                                                    class="button" />
                                                            </fieldset>
                                                        </form>
                                                    </div>
                                                </div>
                                            </figure>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="brands">
    <div class="container">
        <h3>Wedding Organizer</h3>
        <div class="brands-agile">
            <div class="col-md-2 w3layouts-brand">
                <div class="brands-w3l">
                    <p><a href="#">Lorem</a></p>
                </div>
            </div>
            <div class="col-md-2 w3layouts-brand">
                <div class="brands-w3l">
                    <p><a href="#">Lorem</a></p>
                </div>
            </div>
            <div class="col-md-2 w3layouts-brand">
                <div class="brands-w3l">
                    <p><a href="#">Lorem</a></p>
                </div>
            </div>

            <div class="col-md-2 w3layouts-brand">
                <div class="brands-w3l">
                    <p><a href="#">Lorem</a></p>
                </div>
            </div>
            <div class="col-md-2 w3layouts-brand">
                <div class="brands-w3l">
                    <p><a href="#">Lorem</a></p>
                </div>
            </div>
            <div class="col-md-2 w3layouts-brand">
                <div class="brands-w3l">
                    <p><a href="#">Lorem</a></p>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ecom_ilham/resources/views/dashbor/index.blade.php ENDPATH**/ ?>