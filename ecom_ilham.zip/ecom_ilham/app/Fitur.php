<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fitur extends Model
{
    //
}
