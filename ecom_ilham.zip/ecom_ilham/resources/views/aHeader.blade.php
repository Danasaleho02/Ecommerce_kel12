<div class="agileits_header">
    <div class="container">
        <div class="agile-login">
            <ul>
                @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                    <li><a href="{{ route('home') }}">Home</a></li>
                    @else
                    <li><a href="{{ route('login') }}">Login</a></li>
                    @if (Route::has('register'))
                    <li><a href="{{ route('register') }}"> Daftar di sini </a></li>
                    @endif
                    @endauth
                </div>
                @endif
            </ul>
        </div>
        <div class="product_list_header">
            <form action="#" method="post" class="last">
                <input type="hidden" name="cmd" value="_cart">
                <input type="hidden" name="display" value="1">
                <button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down"
                        aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
