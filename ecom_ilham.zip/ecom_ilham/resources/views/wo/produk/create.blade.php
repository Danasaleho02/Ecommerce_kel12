@include('header')
<div class="container">
    <div style="margin-bottom: 25px;" class="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
        <form action="{{ route('produk.store') }}" method="post">
            <div class="form-row">
                <label for="">Nama</label>
                <input type="email" placeholder="Nama" required=" ">
            </div>
            <input type="submit" value="Tambah">
        </form>
    </div>
</div>
@include('footer')
