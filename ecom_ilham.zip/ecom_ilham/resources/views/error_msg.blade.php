@if(count($errors->all()) > 0)
<div class="alert alert-danger">
	@foreach($errors->all() as $error)
	{{ $error }} <br>
	@endforeach
</div>
@endif