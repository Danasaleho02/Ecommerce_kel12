<!DOCTYPE html>
<html>

    <head>
        <title>Organizer.in</title>
        <!-- for-mobile-apps -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="application/x-javascript">
            addEventListener("load", function () {
				setTimeout(hideURLbar, 0);
			}, false);

			function hideURLbar() {
				window.scrollTo(0, 1);
			}
        </script>
        <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet" type="text/css" media="all" />
        <link href="{{ asset('css/style.css') }}" rel="stylesheet" type="text/css" media="all" />
        <link href="{{ asset('css/font-awesome.css') }}" rel="stylesheet">
        <script src="{{ asset('js/jquery-1.11.1.min.js') }}"></script>
        <script src="{{ asset('js/move-top.js') }}" type="text/javascript"></script>
        <script src="{{ asset('js/easing.js') }}" type="text/javascript"></script>

        <script type="text/javascript">
            jQuery(document).ready(function ($) {
				$(".scroll").click(function (event) {
					event.preventDefault();
					$('html,body').animate({
						scrollTop: $(this.hash).offset().top
					}, 1000);
				});
			});
        </script>
    </head>

    <body>
        @include('aHeader')
        @include('logo')
        @include('navbar')

        @yield('content')
